<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>我来自杭州市胜利实验笕成小学</source>
            <comment>Text</comment>
            <translation type="obsolete">我来自杭州市胜利实验笕成小学</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>这是一个多线程的示范</source>
            <comment>Text</comment>
            <translation type="unfinished">这是一个多线程的示范</translation>
        </message>
    </context>
</TS>
