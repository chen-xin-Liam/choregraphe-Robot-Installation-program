<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
    <context>
        <name>behavior_1/behavior.xar:/_学习人脸/_说学习失败</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>学习失败</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/_学习人脸/_说学习成功</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>学习成功</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/_学习人脸/_说开始</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>现在开始学习人脸</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/_识别人脸/_说开始识别人脸</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>开始识别人脸</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
